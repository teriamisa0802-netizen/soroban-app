/* そろばん塾アプリ Firebase 接続版 */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js';
import { getAuth, signInAnonymously, signInWithEmailAndPassword, signOut, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js';
import { getFirestore, collection, doc, getDoc, getDocs, setDoc, deleteDoc, query, where, writeBatch } from 'https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js';

const firebaseConfig = {
  apiKey: 'AIzaSyBixEoluuY--QjANQR9nRZSzJGlu7E_cig',
  authDomain: 'soloban-9fc6f.firebaseapp.com',
  projectId: 'soloban-9fc6f',
  storageBucket: 'soloban-9fc6f.firebasestorage.app',
  messagingSenderId: '918735173497',
  appId: '1:918735173497:web:46dbd706f05775abab21a8',
  measurementId: 'G-F3EY5N6EKN'
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const COLLECTIONS = {
  students:'students', profiles:'studentProfiles', homework:'homework',
  studyLogs:'studyLogs', messages:'messages', history:'history'
};

function randomId(){
  const a=new Uint8Array(18); crypto.getRandomValues(a);
  return Array.from(a,b=>b.toString(16).padStart(2,'0')).join('');
}
function now(){return new Date().toISOString();}
function isTeacher(){return !!auth.currentUser && !auth.currentUser.isAnonymous;}
function studentKey(){return localStorage.getItem('sorobanStudentId')||'';}
async function studentAnonymousLogin(){
  if(auth.currentUser?.isAnonymous) return auth.currentUser;
  return (await signInAnonymously(auth)).user;
}
async function teacherLogin(email,password){
  if(!email||!password) throw new Error('メールアドレスとパスワードを入力してください。');
  const r=await signInWithEmailAndPassword(auth,email,password);
  if(r.user.isAnonymous) throw new Error('先生用アカウントでログインしてください。');
  return r.user;
}

async function createStudent(realName,nickname){
  realName=String(realName||'').trim();
  nickname=String(nickname||'').trim();
  if(!realName) throw new Error('本名を入力してください。');
  if(!nickname) throw new Error('ニックネームを入力してください。');

  const user=await studentAnonymousLogin();

  const snaps=await getDocs(collection(db,COLLECTIONS.students));
  if(snaps.size>=5) throw new Error('このアプリには5人まで登録できます。');

  const duplicate=snaps.docs.some(d=>{
    const s=d.data();
    return String(s.nickname||s.name||'').trim()===nickname;
  });
  if(duplicate) throw new Error('そのニックネームはすでに登録されています。');

  // One anonymous Firebase account represents the student on this device.
  const id=randomId();
  const created=now();

  await setDoc(doc(db,COLLECTIONS.students,id),{
    id, nickname, name:nickname, realName, uid:user.uid, created, exp:0
  });
  await setDoc(doc(db,COLLECTIONS.profiles,id),{
    nickname, uid:user.uid, updatedAt:created
  });

  localStorage.setItem('sorobanStudentId',id);
  return {id,nickname,realName,uid:user.uid,created};
}

async function getStudent(studentId){
  const snap=await getDoc(doc(db,COLLECTIONS.students,studentId));
  return snap.exists()?{...snap.data(),id:snap.id}:null;
}
async function getStudentData(studentId){
  const out={};
  for(const type of ['homework','studyLogs','messages','history']){
    const q=query(collection(db,COLLECTIONS[type]),where('studentId','==',studentId));
    const snaps=await getDocs(q);
    out[type]=snaps.docs.map(d=>({...d.data(),id:d.id}));
  }
  return out;
}
async function saveCollection(type,items){
  if(!COLLECTIONS[type]||!auth.currentUser) return;
  const user=auth.currentUser;
  const batch=writeBatch(db);
  const c=collection(db,COLLECTIONS[type]);

  for(const item of items){
    if(!item?.id) continue;
    if(type!=='students'&&type!=='profiles'&&user.isAnonymous&&item.studentId!==studentKey()) continue;
    batch.set(doc(c,String(item.id)),{...item,updatedAt:now()},{merge:true});
  }
  await batch.commit();
}
async function deleteCollectionItem(type,id){
  if(!COLLECTIONS[type]) return;
  await deleteDoc(doc(db,COLLECTIONS[type],String(id)));
}
async function teacherLoadAll(){
  if(!isTeacher()) throw new Error('先生としてログインしてください。');
  const out={};
  for(const type of ['students','homework','studyLogs','messages','history']){
    const snaps=await getDocs(collection(db,COLLECTIONS[type]));
    out[type]=snaps.docs.map(d=>({...d.data(),id:d.id}));
  }
  return out;
}
async function teacherDeleteStudent(studentId){
  if(!isTeacher()) throw new Error('先生としてログインしてください。');
  await deleteDoc(doc(db,COLLECTIONS.students,studentId));
  await deleteDoc(doc(db,COLLECTIONS.profiles,studentId));
  for(const type of ['homework','studyLogs','messages','history']){
    const q=query(collection(db,COLLECTIONS[type]),where('studentId','==',studentId));
    const snaps=await getDocs(q);
    const batch=writeBatch(db);
    snaps.docs.forEach(d=>batch.delete(d.ref));
    await batch.commit();
  }
}
onAuthStateChanged(auth,user=>{
  window.dispatchEvent(new CustomEvent('soroban-auth',{detail:{user,isTeacher:!!user&&!user.isAnonymous}}));
});
window.SorobanCloud={
  auth,db,isTeacher,studentAnonymousLogin,teacherLogin,createStudent,
  getStudent,getStudentData,saveCollection,deleteCollectionItem,
  teacherLoadAll,teacherDeleteStudent,signOut
};
